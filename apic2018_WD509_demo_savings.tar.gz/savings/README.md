## WD514
#  Create, secure, and publish APIS with API Connect V2018

#  Unit: Create an API definition
#  6 March 2017 (original)

The purpose of this demonstration is to create an API definition
that describes an existing REST service. In this example, the
savings_1.0.0.yaml API definition forwards API requests to the
Bluemix hosted API: https://savingsample.mybluemix.net. 

When you present this demonstration, create an API definition
from scratch according to the instructions in Unit 3.

To test this completed version of the demonstration, run `apic edit`.
Publish the savings_1.0.0.yaml API to the micro gateway. Test the
GET and POST /Plans/estimate API operations in the Explore view.
