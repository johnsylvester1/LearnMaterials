## WD514
#  Create, secure, and publish APIS with API Connect V2018

#  Unit: Define APIs that call REST and SOAP services
#  6 March 2017 (original)

The purpose of this demonstration is to generate an API definition
from an existing WSDL document. You must keep a copy of the WSDL
document in the same directory as the API definition file to test
the API in the API Designer web application.

When you present this demonstration, download a copy of the WSDL
document from the Bluemix hosted SOAP service:
https://soapsample.mybluemix.net

To test this completed version of the demonstration, run `apic edit`
and publish the itemservice_1.0.0.yaml API to the micro gateway.
Test the getInventory operation with the Explore view.
