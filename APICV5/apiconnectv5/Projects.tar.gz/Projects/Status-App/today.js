
module.exports = function()
{
var date = new Date();
var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday', 'Friday','Saturday','Sunday'];
return days[date.getDay()];


}
//console.log('Today day is %s',today);
