var today = require('./today');
var express = require('express');
var request = require('request');

var app = express();
var port = 3000;

app.get('/api/today',function (request,response){

  var body = " Today is " + today();

  response.type('text/plain');
  response.set('Content-Length',Buffer.byteLength(body));
  response.status(200).send(body);

});

app.get('/api/weather',function (req,response){

  var options =
  {
    method : 'GET',
    url : 'http://weather.gov/xml/current_obs/KSFO.xml',
    headers :{
      'User-agent' : 'weatherRequest/1.0'
            }
  };

  var callback = function (error,resp,body)
  {
    response.type('text/html');
    response.status(resp.statusCode).send(body);
  }
  request(options,callback);

  //response.type('text/plain');
  //response.set('Content-Length',Buffer.byteLength(body));
  //response.status(200).send(body);

});




app.listen(port,function() {
  console.log("Listening on port %s",port);
})
//console.log('Today is %s',today());
