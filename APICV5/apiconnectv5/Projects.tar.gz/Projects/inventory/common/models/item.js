module.exports = function(Item) {
  Item.afterRemote('*',function(ctx,remoteMethodOutput,next)
  {
    console.log("Remote hook call afterRemote........");
  });
  next();

};
