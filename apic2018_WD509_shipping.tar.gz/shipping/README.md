## WD514/ZD514
#  Create, secure, and publish APIs with API Connect V2018

# shipping back-end
# not implemented in WD514 - optional

Run 'npm start' to run this application.
The results can be seen by running either of these two URLs:
http://localhost:5500/calculate?company=cek&from_zip=90210&to_zip={zip}
http://localhost:5500/calculate?company=xyz&from_zip=90210&to_zip={zip}
