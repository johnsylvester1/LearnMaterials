## WD514
#  Create, secure, and publish APIS with API Connect V2018

#  Exercise: Define an API that calls an existing SOAP service

To test this completed version of the demonstration, sign on to API Manager
with the user credentials of the owner of the provider organization.
In the Develop APIs and Products page, select Add, then select API.
Choose the option to import an API from an existing WSDL service (SOAP proxy).
Select the ItemService.wsdl file during the import process.
After importing the WSDL file, edit the API definition.
Then, select the Assemble tab and test the API from the test option according 
to the instructions in the student exercise guide.
