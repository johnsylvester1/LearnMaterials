## WD514
#  Create, secure, and publish APIS with API Connect V2018

#  Unit: Implement APIs with the LoopBack framework
#  6 March 2017 (original)

The purpose of this demonstration is to develop, test, and run a REST
operation that runs arbitrary code. In this example, the 'lookupPrice'
remote method forwards the API request to a REST endpoint at:
https://pricesample.mybluemix.net/price/{id}

When you present this demonstration, build each part of the LoopBack
application according to the instructions in Unit 5.

To test this completed version of the demonstration, run `npm install`
first. Start the LoopBack server with `npm start`.
Open http://localhost:3000/api/products/lookupPrice/{id} to test the
API operation.
