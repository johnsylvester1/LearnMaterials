## WD514/ZD514
#  Create, secure, and publish APIs with API Connect V2018

# Exercise 8: Declare an OAuth 2.0 provider and security requirement
# 5 Mar 2019 

You must run 'npm install' to retrieve the npm modules for this application.
