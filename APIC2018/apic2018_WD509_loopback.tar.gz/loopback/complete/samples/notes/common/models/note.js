module.exports = function(Note) {
};
