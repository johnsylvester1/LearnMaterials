module.exports = function(server, callback) {
  var ds = server.dataSources.memoryds;

  ds.once('connected', function() {

    // Define a JSON document with sample data
    var article = {
      title: 'Create, secure, and publish APIs with IBM API Connect',
      author: 'anonymous',
      address: {
        street: '123 Main Street',
        city: 'Parksville',
        region: 'British Columbia',
        postcode: 'V7J 3R1',
        country: 'Canada'
      },
      email: [
        {label: 'work', id: 'poorjoe@example.com'}
      ],
      tags: ['ibm', 'cloud', 'apiconnect']
    }
    // Create a persisted model named 'Article', based on the
    // structure of the 'article' JSON document.
    var Article =
      ds.buildModelFromInstance(
        'PersistedModel', article, {idInjection: true}
    );

    // Create an instance of 'Article' model with the contents of the
    // 'article' document.
    var modelInstance = new Article(article);
    console.log(modelInstance.toObject());

    // Persist the 'article' model instance in the data source.
    Article.create(article, function (err, createdmodel) {
      console.log('Created: ', createdmodel.toObject());
      Article.findById(createdmodel.id, function (err, foundmodel) {
        console.log('Found: ', foundmodel.toObject());
      });
    });

    callback();
  }); // ds.once
}; // introspection
