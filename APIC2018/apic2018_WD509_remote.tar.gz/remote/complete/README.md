## WD514/ZD514
#  Create, secure, and publish APIs with API Connect V2018

# Exercise 6: Implement event-driven functions with remote and operation hooks
# 5 Mar 2019 - kevinom

You must run 'npm install' to retrieve the npm modules for this application.
