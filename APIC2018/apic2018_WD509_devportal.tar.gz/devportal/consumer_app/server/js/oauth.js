var Promise = require('promise');
var UrlPattern = require('url-pattern');
var ClientOAuth2 = require('client-oauth2');
var config = require('config');
var util = require('util');

var api_url = new UrlPattern('(:protocol)\\://(:host)(/:org)(/:cat)(:api)(:operation)');
var _myApp = config.get('Application');
var _apiServer = config.get('API-Server');
var _apiServerOrg = ((_apiServer.org == "") || (typeof _apiServer.org == 'undefined')) ? undefined : _apiServer.org;
var _apiServerCatalog = ((_apiServer.catalog == "") || (typeof _apiServer.catalog == 'undefined')) ? undefined : _apiServer.catalog;
var _apis = config.get('APIs');
var _undefmsg = "(undefined)";

module.exports.login = function (username, password, session) {

  return new Promise(function (fulfill, reject) {
    if (typeof session.oauth2token !== 'undefined') {
      console.log("\nUsing Access Token: %s\n", session.oauth2token);
      fulfill(session.oauth2token);
    }
    else {

      var authz_url = api_url.stringify({
        protocol: _apiServer.protocol,
        host: _apiServer.host,
        org: _apiServerOrg,
        cat: _apiServerCatalog,
        api: _apis.oauth20.base_path,
        operation: _apis.oauth20.paths.authz
      });

      var token_url = api_url.stringify({
        protocol: _apiServer.protocol,
        host: _apiServer.host,
        org: _apiServerOrg,
        cat: _apiServerCatalog,
        api: _apis.oauth20.base_path,
        operation: _apis.oauth20.paths.token
      });

      var oauth_params = util.format(
        "Authorization URL:  %s\n" +
        "Token URL:          %s\n" +
        "Client ID:          %s\n" +
        "Client Secret:      %s\n" +
        "Auth Grant Type:    %s\n" +
        "Redirect URI:       %s\n" +
        "Scope:              %s\n",
        authz_url,
        token_url,
        _myApp.client_id ? _myApp.client_id : _undefmsg, _myApp.client_secret ? _myApp.client_secret : _undefmsg,
        _apis.oauth20.grant_types,
        _apis.oauth20.redirect_url ? _myApp.oauth20.redirect_url : _undefmsg,
        _apis.oauth20.scopes
      );
      console.log(
        "\nInitializing OAuth client...\n" +
        oauth_params
      );
        
      if ( !_myApp.client_id || !_myApp.client_secret) {
        reject({ 
          'message':
            "Error: Client ID and client secret cannot be blank.\n" +
            "       Add the correct values into the config/default.json file.",
          'error': {
            'status': 'Before OAuth authorize',
            'stack': oauth_params
          }
        });
      }
        
      if ( !username || !password ) {
       reject({ 
          'message':
            "Error: Username and password cannot be blank.\n" +
            "       Enter any characters into the form.",
          'error': {
            'status': 'Before OAuth authorize',
            'stack': oauth_params
          }
        });
      }
        
      var thinkAuth = new ClientOAuth2({
        clientId: _myApp.client_id,
        clientSecret: _myApp.client_secret,
        accessTokenUri: token_url,
        authorizationUri: authz_url,
        authorizationGrants: _apis.oauth20.grant_types,
        redirectUri: _apis.oauth20.redirect_url,
        scopes: _apis.oauth20.scopes
      });

      // Set an option to disable the check for self-signed certificates
      var options = {
        options: {
          rejectUnauthorized: false
        }
      };

      thinkAuth.owner.getToken(username, password, options)
        .then(function (user) {
          session.oauth2token = user.accessToken;
          console.log(
            "... authorize and token calls successful.\n"+
            "Using Access Token:  %s",
            session.oauth2token
          );
          fulfill(session.oauth2token);
        })
        .catch(function (reason) {
          console.log(
            "... cannot retrieve OAuth access token.\n" +
            "Reason: %s\n",
            JSON.stringify(reason)
          );
          reject({ 
            'message':
              "Error: Cannot retrieve OAuth access token.\n" +
              "Reason: " + JSON.stringify(reason) + "\n",
            'error': {
              'status': 'During OAuth authorize',
              'stack': oauth_params
            }
          });
       });
    }
  });

};