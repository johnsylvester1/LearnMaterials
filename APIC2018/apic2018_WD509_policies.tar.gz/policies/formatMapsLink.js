// Require API Connect functions
var apim = require('apim');

// Save the geocode service response body to a variable
var mapsApiResponse = apim.getvariable('geocode_response.body');

// Get location attributes from the response message
var location = mapsApiResponse[0];

var storesResponse = {
  "maps_link": 'https://www.openstreetmap.org/#map=16/' +
    location.lat + '/' + location.lon
};

// Save the output
apim.setvariable('message.body', storesResponse);
