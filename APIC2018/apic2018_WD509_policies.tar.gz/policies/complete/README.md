## WD514/ZD514
#  Create, secure, and publish APIs with API Connect V2018

# Exercise 7: Assemble message processing policies
# 8 Feb 2019 - kevinom

You must run 'npm install' to retrieve the npm modules for this application.
