'use strict';

module.exports = function(Product) {

};
