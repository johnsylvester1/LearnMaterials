## WD514
#  Create, secure, and publish APIS with API Connect V2018

#  Unit: Defining data sources with connectors

The purpose of this demonstration is to create a LoopBack local file application.
This product demonstration is how the data is loaded and persisted in the sample
https://pricesample.mybluemix.net/price/ application.
The application is build with LoopBack in NodeJS and then deployed on the IBM Cloud.

When you present this demonstration, build each part of the LoopBack
application according to the instructions in Unit 7.

To test this completed version of the demonstration, run `npm install`
first. Start the LoopBack server with `npm start`.
Open the LoopBack Explorer at http://localhost:3000/explorer and select
the POST /products API operation to add data to the local file.
