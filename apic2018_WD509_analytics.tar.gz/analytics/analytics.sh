#! /bin/bash
# load data for analytics
# API Connect Education
USAGE="Usage analytics GET products"

#option processing
if [ $# == 0 ]; then
echo $USAGE
else
echo $#
exit 1;
fi

#main curl statement in loop
i="0"
while [ $i -le 50 ]
do
curl -k --request GET \
  --url 'https://apigw.think.ibm/think/staging/smart/v1/products' \
  --header 'accept: application/json' \
  --header 'content-type: application/json' \
  --header 'X-IBM-Client-Id: a48eb57cef6ddfadece4e721cc06d871'
i=$[$i+1]
done
