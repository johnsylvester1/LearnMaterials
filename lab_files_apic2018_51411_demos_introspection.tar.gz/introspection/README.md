## WD514
#  Create, secure, and publish APIS with API Connect V2018

#  Unit: Defining datasources with connectors
#  /lab_files/demos/introspection 

The purpose of this demonstration is to create a model from a JSON datasource
by using introspection

The instructions to build the LoopBack model yourself are in Unit 7.

To test this completed version of the demonstration, run `npm install`
from the root directory of the app. 
Start the LoopBack server with `npm start`.

The introspection output is written to the file that is named in
/server/datasources.json in the app root folder
