'use strict';

module.exports = function(Review) {

};
