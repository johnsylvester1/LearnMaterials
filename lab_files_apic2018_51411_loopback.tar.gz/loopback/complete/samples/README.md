## WD514/ZD514
#  Create, secure, and publish APIs with API Connect V2018

# Exercise 4: Create a LoopBack application
# Students are encouraged to complete the exercise as written

You must run 'npm install' to retrieve the npm modules for this application.
