## WD514
#  Create, secure, and publish APIS with API Connect V2018

#  Exercise: Create an API definition from an existing API

To test this completed version of the demonstration, sign on to API Manager
with the user credentials of the owner of the provider organization.
In the Develop APIs and Products page, select Add, then select API.
Choose the option to import an API from an existing OpenAPI definition.
Select the saving_1.0.0.yaml file during the import process.
After importing the YAML file, edit the API definition.
Then, select the Assemble tab and test the API from the test option.
